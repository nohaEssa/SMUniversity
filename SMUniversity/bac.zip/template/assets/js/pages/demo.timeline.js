/*------------------------------------------------------------------
 [ TIME-LINE Trigger Javascript ]

 Project     :	Fickle Responsive Admin Template
 Version     :	1.0
 Author      : 	AimMateTeam
 URL         :  http://aimmate.com
 Support     :  aimmateteam@gmail.com
 Primary use :	Time-line

 -------------------------------------------------------------------*/

/*-----------------------------------------------*/
jQuery(document).ready(function($) {
    'use strict';

    light_Gallery();
});

/*---------------- LIGHT-GALLERY POPUP -------------------*/
function light_Gallery(){
    'use strict';

    $("#ls-timeline-project").lightGallery();
}
