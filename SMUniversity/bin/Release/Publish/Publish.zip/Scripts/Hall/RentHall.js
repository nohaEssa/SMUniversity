﻿function toogle() {
    debugger
    $('#LecturerID').val() == "-1" ? $('.LecturerData').show() : $('.LecturerData').hide();
}