﻿$(window).load(function () {

    $('#LecturerIDs').multipleSelect({
        placeholder: "اختر محاضرين",
        filter: true,
        width: '100%'
    });
});